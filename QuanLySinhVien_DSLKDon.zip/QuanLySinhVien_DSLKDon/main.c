#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// ================= KHAI BAO CAU TRUC =================

typedef struct {
    char hoten[30];
    int masv;
    float d1, d2, d3;
} Data;

typedef struct tagNode {
    Data infor;
    struct tagNode *link;
} Node;

typedef struct {
    Node *pHead;
    Node *pTail;
    int spt;
} LList;

// ================= KHOI TAO DANH SACH =================

void initList(LList *L) {
    L->pHead = NULL;
    L->pTail = NULL;
    L->spt = 0;
}

int emptyList(LList L) {
    return L.spt == 0;
}

// ================= NHAP DU LIEU =================

int readInt(const char *message) {
    char s[100];
    int n;

    while (1) {
        printf("%s", message);
        if (fgets(s, sizeof(s), stdin) == NULL)
            return 0;

        if (sscanf(s, "%d", &n) == 1)
            return n;

        printf("Du lieu khong hop le!\\n");
    }
}

float readFloat(const char *message) {
    char s[100];
    float n;

    while (1) {
        printf("%s", message);
        if (fgets(s, sizeof(s), stdin) == NULL)
            return 0;

        if (sscanf(s, "%f", &n) == 1)
            return n;

        printf("Du lieu khong hop le!\\n");
    }
}

void nhap(Data *x) {
    x->masv = readInt("Nhap ma sinh vien: ");

    printf("Nhap ho ten: ");
    if (fgets(x->hoten, sizeof(x->hoten), stdin) == NULL)
        x->hoten[0] = '\\0';
    x->hoten[strcspn(x->hoten, "\\n")] = '\\0';

    do {
        x->d1 = readFloat("Nhap diem mon 1: ");
        x->d2 = readFloat("Nhap diem mon 2: ");
        x->d3 = readFloat("Nhap diem mon 3: ");

        if (x->d1 < 0 || x->d1 > 10 ||
            x->d2 < 0 || x->d2 > 10 ||
            x->d3 < 0 || x->d3 > 10)
            printf("Diem phai nam trong khoang 0-10!\\n");

    } while (x->d1 < 0 || x->d1 > 10 ||
             x->d2 < 0 || x->d2 > 10 ||
             x->d3 < 0 || x->d3 > 10);
}

// ================= IN DU LIEU =================

float diemTB(Data x) {
    return (x.d1 + x.d2 + x.d3) / 3;
}

void in(Data x) {
    printf("%-10d %-25s %6.2f %6.2f %6.2f %8.2f\\n",
           x.masv, x.hoten, x.d1, x.d2, x.d3, diemTB(x));
}

void processList(LList L) {
    Node *pp = L.pHead;

    if (emptyList(L)) {
        printf("Danh sach rong!\\n");
        return;
    }

    printf("\\n%-10s %-25s %6s %6s %6s %8s\\n",
           "Ma SV", "Ho ten", "Diem 1", "Diem 2",
           "Diem 3", "Diem TB");

    while (pp != NULL) {
        in(pp->infor);
        pp = pp->link;
    }

    printf("Tong so sinh vien: %d\\n", L.spt);
}

// ================= TAO NODE =================

Node *createNode(Data x) {
    Node *p = (Node*)malloc(sizeof(Node));

    if (p == NULL) {
        printf("Khong du bo nho!\\n");
        return NULL;
    }

    p->infor = x;
    p->link = NULL;

    return p;
}

// ================= THEM DAU =================

void insert_Head(LList *L, Data x) {
    Node *p = createNode(x);

    if (p == NULL) return;

    if (emptyList(*L)) {
        L->pHead = L->pTail = p;
    } else {
        p->link = L->pHead;
        L->pHead = p;
    }

    L->spt++;
}

// ================= THEM CUOI =================

void insert_Tail(LList *L, Data x) {
    Node *p = createNode(x);

    if (p == NULL) return;

    if (emptyList(*L)) {
        L->pHead = L->pTail = p;
    } else {
        L->pTail->link = p;
        L->pTail = p;
    }

    L->spt++;
}

// ================= TIM KIEM THEO MA =================

Node *search_Ma(LList L, int ma) {
    Node *p = L.pHead;

    while (p != NULL) {
        if (p->infor.masv == ma)
            return p;

        p = p->link;
    }

    return NULL;
}

// ================= TIM KIEM THEO TEN =================

void search_Ten(LList L, char ten[]) {
    Node *p = L.pHead;
    int found = 0;

    while (p != NULL) {
        if (strstr(p->infor.hoten, ten) != NULL) {
            if (!found) {
                printf("\\nKet qua tim kiem:\\n");
                printf("%-10s %-25s %6s %6s %6s %8s\\n",
                       "Ma SV", "Ho ten", "Diem 1",
                       "Diem 2", "Diem 3", "Diem TB");
            }

            in(p->infor);
            found = 1;
        }

        p = p->link;
    }

    if (!found)
        printf("Khong tim thay sinh vien!\\n");
}

// ================= XOA THEO MA =================

int delete_Ma(LList *L, int ma) {
    Node *p = L->pHead;
    Node *prev = NULL;

    while (p != NULL) {
        if (p->infor.masv == ma) {
            if (prev == NULL)
                L->pHead = p->link;
            else
                prev->link = p->link;

            if (p == L->pTail)
                L->pTail = prev;

            free(p);
            L->spt--;

            return 1;
        }

        prev = p;
        p = p->link;
    }

    return 0;
}

// ================= XOA THEO TEN =================

int delete_Ten(LList *L, char ten[]) {
    Node *p = L->pHead;
    Node *prev = NULL;
    int count = 0;

    while (p != NULL) {
        if (strcmp(p->infor.hoten, ten) == 0) {
            Node *temp = p;

            if (prev == NULL)
                L->pHead = p->link;
            else
                prev->link = p->link;

            p = p->link;

            if (temp == L->pTail)
                L->pTail = prev;

            free(temp);
            L->spt--;
            count++;
        } else {
            prev = p;
            p = p->link;
        }
    }

    return count;
}

// ================= THEM SAU MOT MA SV =================

void insert_After(LList *L, int ma, Data x) {
    Node *p = search_Ma(*L, ma);

    if (p == NULL) {
        printf("Khong tim thay ma sinh vien!\\n");
        return;
    }

    Node *q = createNode(x);
    if (q == NULL) return;

    q->link = p->link;
    p->link = q;

    if (p == L->pTail)
        L->pTail = q;

    L->spt++;

    printf("Them thanh cong!\\n");
}

// ================= SAP XEP THEO TEN =================

void sort_Ten(LList *L) {
    Node *p, *q;
    Data temp;

    for (p = L->pHead; p != NULL; p = p->link) {
        for (q = p->link; q != NULL; q = q->link) {
            if (strcmp(p->infor.hoten, q->infor.hoten) > 0) {
                temp = p->infor;
                p->infor = q->infor;
                q->infor = temp;
            }
        }
    }

    printf("Da sap xep theo ten!\\n");
}

// ================= SAP XEP THEO MA =================

void sort_Ma(LList *L) {
    Node *p, *q;
    Data temp;

    for (p = L->pHead; p != NULL; p = p->link) {
        for (q = p->link; q != NULL; q = q->link) {
            if (p->infor.masv > q->infor.masv) {
                temp = p->infor;
                p->infor = q->infor;
                q->infor = temp;
            }
        }
    }

    printf("Da sap xep theo ma SV!\\n");
}

// ================= XEP LOAI =================

void xepLoai(LList L) {
    Node *p = L.pHead;

    while (p != NULL) {
        float tb = diemTB(p->infor);

        printf("Ma SV: %d - Ten: %s - Diem TB: %.2f - ",
               p->infor.masv, p->infor.hoten, tb);

        if (tb >= 8)
            printf("Gioi\\n");
        else if (tb >= 6.5)
            printf("Kha\\n");
        else if (tb >= 5)
            printf("Trung binh\\n");
        else
            printf("Yeu\\n");

        p = p->link;
    }
}

// ================= TACH DANH SACH =================

void splitList(LList *L1, LList *L2, int n) {
    if (!emptyList(*L2)) {
        printf("Danh sach L2 phai rong truoc khi tach!\\n");
        return;
    }

    if (n < 0 || n > L1->spt) {
        printf("So luong tach khong hop le!\\n");
        return;
    }

    if (n == L1->spt) {
        printf("Khong con phan tu de tach!\\n");
        return;
    }

    if (n == 0) {
        *L2 = *L1;
        initList(L1);
        return;
    }

    Node *p = L1->pHead;

    for (int i = 1; i < n; i++)
        p = p->link;

    L2->pHead = p->link;
    L2->pTail = L1->pTail;
    L2->spt = L1->spt - n;

    p->link = NULL;

    L1->pTail = p;
    L1->spt = n;

    printf("Tach danh sach thanh cong!\\n");
}

// ================= GHEP DANH SACH =================

void mergeList(LList *L1, LList *L2) {
    if (emptyList(*L2)) {
        printf("Danh sach L2 rong!\\n");
        return;
    }

    if (emptyList(*L1)) {
        *L1 = *L2;
    } else {
        L1->pTail->link = L2->pHead;
        L1->pTail = L2->pTail;
        L1->spt += L2->spt;
    }

    initList(L2);

    printf("Ghep danh sach thanh cong!\\n");
}

// ================= GIAI PHONG BO NHO =================

void clearList(LList *L) {
    Node *p = L->pHead;

    while (p != NULL) {
        Node *temp = p;
        p = p->link;
        free(temp);
    }

    initList(L);
}

// ================= CHUONG TRINH CHINH =================

int main() {
    LList L, L2;
    Data x;
    int chon, ma, n;
    char ten[30];

    initList(&L);
    initList(&L2);

    do {
        printf("\\n========== QUAN LY SINH VIEN ==========\\n");
        printf("1. Them sinh vien vao dau\\n");
        printf("2. Them sinh vien vao cuoi\\n");
        printf("3. Them sau mot ma sinh vien\\n");
        printf("4. Xoa sinh vien theo ma\\n");
        printf("5. Xoa sinh vien theo ten\\n");
        printf("6. Tim kiem theo ma\\n");
        printf("7. Tim kiem theo ten\\n");
        printf("8. Sap xep theo ten\\n");
        printf("9. Sap xep theo ma\\n");
        printf("10. Duyet danh sach L1\\n");
        printf("11. Duyet danh sach L2\\n");
        printf("12. Xep loai sinh vien\\n");
        printf("13. Tach danh sach L1 thanh L1 va L2\\n");
        printf("14. Ghep L2 vao L1\\n");
        printf("0. Thoat\\n");
        printf("=======================================\\n");

        chon = readInt("Moi ban chon: ");

        switch (chon) {
            case 1:
                nhap(&x);
                insert_Head(&L, x);
                break;

            case 2:
                nhap(&x);
                insert_Tail(&L, x);
                break;

            case 3:
                ma = readInt("Nhap ma SV can them sau: ");
                printf("Nhap thong tin sinh vien moi:\\n");
                nhap(&x);
                insert_After(&L, ma, x);
                break;

            case 4:
                ma = readInt("Nhap ma SV can xoa: ");

                if (delete_Ma(&L, ma))
                    printf("Xoa thanh cong!\\n");
                else
                    printf("Khong tim thay sinh vien!\\n");
                break;

            case 5:
                printf("Nhap ho ten can xoa: ");
                if (fgets(ten, sizeof(ten), stdin) == NULL)
                    ten[0] = '\\0';
                ten[strcspn(ten, "\\n")] = '\\0';

                n = delete_Ten(&L, ten);
                printf("Da xoa %d sinh vien!\\n", n);
                break;

            case 6: {
                ma = readInt("Nhap ma SV can tim: ");
                Node *p = search_Ma(L, ma);

                if (p != NULL)
                    in(p->infor);
                else
                    printf("Khong tim thay!\\n");
                break;
            }

            case 7:
                printf("Nhap ten can tim: ");
                if (fgets(ten, sizeof(ten), stdin) == NULL)
                    ten[0] = '\\0';
                ten[strcspn(ten, "\\n")] = '\\0';

                search_Ten(L, ten);
                break;

            case 8:
                sort_Ten(&L);
                break;

            case 9:
                sort_Ma(&L);
                break;

            case 10:
                processList(L);
                break;

            case 11:
                processList(L2);
                break;

            case 12:
                xepLoai(L);
                break;

            case 13:
                n = readInt("Nhap so node giu lai trong L1: ");
                splitList(&L, &L2, n);
                break;

            case 14:
                mergeList(&L, &L2);
                break;

            case 0:
                printf("Dang giai phong bo nho...\\n");
                clearList(&L);
                clearList(&L2);
                printf("Bye bye!\\n");
                break;

            default:
                printf("Lua chon khong hop le!\\n");
        }

    } while (chon != 0);

    return 0;
}
