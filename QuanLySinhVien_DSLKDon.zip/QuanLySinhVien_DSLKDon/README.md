# QUẢN LÝ SINH VIÊN BẰNG DANH SÁCH LIÊN KẾT ĐƠN (C)

## 1. Giới thiệu
Chương trình quản lý thông tin sinh viên sử dụng cấu trúc dữ liệu danh sách liên kết đơn (Singly Linked List) trong ngôn ngữ lập trình C.

Mỗi node lưu trữ mã sinh viên, họ tên và điểm của ba môn học.

## 2. Các chức năng
1. Thêm sinh viên vào đầu danh sách.
2. Thêm sinh viên vào cuối danh sách.
3. Thêm sinh viên sau một mã sinh viên.
4. Xóa sinh viên theo mã.
5. Xóa sinh viên theo tên.
6. Tìm kiếm sinh viên theo mã.
7. Tìm kiếm sinh viên theo tên.
8. Sắp xếp sinh viên theo tên.
9. Sắp xếp sinh viên theo mã.
10. Tính điểm trung bình và xếp loại.
11. Tách danh sách thành hai danh sách.
12. Ghép hai danh sách.
13. Hiển thị danh sách sinh viên.

## 3. Kiến thức áp dụng
- Struct trong C.
- Con trỏ (Pointer).
- Cấp phát và giải phóng bộ nhớ động (`malloc`, `free`).
- Danh sách liên kết đơn.
- Các thao tác thêm, xóa, tìm kiếm và sắp xếp.

## 4. Công nghệ
- Ngôn ngữ: C
- Thư viện: `stdio.h`, `stdlib.h`, `string.h`

## 5. Cách biên dịch và chạy
Sử dụng trình biên dịch hỗ trợ C99 trở lên:

```bash
gcc main.c -o quanlysv
./quanlysv
```

Trên Windows:

```bash
gcc main.c -o quanlysv.exe
quanlysv.exe
```

## 6. Tác giả
Bài thực hành cấu trúc dữ liệu và giải thuật.
